// Shrinks the captured photo client-side before upload so the payload
// stays small on slow rural 3G connections.
export function compressImage(file, maxWidth = 800, quality = 0.6) {
  return new Promise((resolve) => {
    const img = new Image()
    img.src = URL.createObjectURL(file)
    img.onload = () => {
      const scale = Math.min(1, maxWidth / img.width)
      const canvas = document.createElement('canvas')
      canvas.width = img.width * scale
      canvas.height = img.height * scale
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height)
      canvas.toBlob((blob) => resolve(blob), 'image/jpeg', quality)
    }
  })
}

// Fetch with a timeout and a couple of retries, so one dropped packet
// doesn't fail the whole scan.
export async function fetchWithRetry(url, options, retries = 2, timeout = 8000) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController()
    const id = setTimeout(() => controller.abort(), timeout)
    try {
      const res = await fetch(url, { ...options, signal: controller.signal })
      clearTimeout(id)
      return res
    } catch (err) {
      clearTimeout(id)
      if (attempt === retries) throw err
    }
  }
}
