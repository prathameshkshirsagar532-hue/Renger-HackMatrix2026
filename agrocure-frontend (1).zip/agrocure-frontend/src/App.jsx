import { useState, useRef } from 'react'
import { compressImage, fetchWithRetry } from './utils'

// 👇 replace with your real FastAPI Gateway URL
const API_URL = 'https://your-fastapi-host/api/diagnose'

export default function App() {
  const [status, setStatus] = useState('idle') // idle | scanning | result | error
  const [previewUrl, setPreviewUrl] = useState(null)
  const [result, setResult] = useState(null)
  const inputRef = useRef(null)

  const handleCapture = (file) => {
    setPreviewUrl(URL.createObjectURL(file))
    runInference(file)
  }

  async function runInference(file) {
    setStatus('scanning')
    try {
      const compressed = await compressImage(file)
      const formData = new FormData()
      formData.append('image', compressed)

      const res = await fetchWithRetry(API_URL, {
        method: 'POST',
        body: formData,
      })
      if (!res.ok) throw new Error('Server error')

      const data = await res.json()
      setResult(data)
      setStatus('result')
      speakHindi(data.advice_hi)
    } catch (err) {
      setStatus('error')
    }
  }

  function speakHindi(text) {
    if (!text || !window.speechSynthesis) return
    const utter = new SpeechSynthesisUtterance(text)
    utter.lang = 'hi-IN'
    utter.rate = 0.95
    const hindiVoice = window.speechSynthesis.getVoices().find((v) => v.lang === 'hi-IN')
    if (hindiVoice) utter.voice = hindiVoice
    window.speechSynthesis.speak(utter)
  }

  const reset = () => {
    setStatus('idle')
    setPreviewUrl(null)
    setResult(null)
  }

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col items-center px-4 py-8">
      <h1 className="text-xl font-semibold text-green-800 mb-6">AgroCure Lens AI</h1>

      {status === 'idle' && (
        <>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => e.target.files[0] && handleCapture(e.target.files[0])}
          />
          <button
            onClick={() => inputRef.current.click()}
            className="w-full max-w-xs py-4 rounded-2xl bg-green-600 text-white font-medium text-lg active:scale-95 transition"
          >
            Scan Crop Leaf
          </button>
        </>
      )}

      {status === 'scanning' && (
        <p className="mt-10 font-mono text-green-700 animate-pulse">[SCANNING...]</p>
      )}

      {status === 'result' && previewUrl && result && (
        <div className="w-full max-w-xs">
          <div className="relative rounded-2xl overflow-hidden shadow">
            <img src={previewUrl} className="w-full" alt="Scanned leaf" />
            {result.detections?.map((d, i) => (
              <span
                key={i}
                className="absolute w-3 h-3 bg-orange-500 rounded-full ring-2 ring-white"
                style={{ left: `${d.x}%`, top: `${d.y}%` }}
              />
            ))}
            <div className="absolute bottom-2 left-2 bg-white/90 text-orange-600 text-xs font-medium px-2 py-1 rounded-full">
              {result.label}
            </div>
          </div>
          <button
            onClick={reset}
            className="mt-4 w-full py-3 rounded-2xl border border-green-600 text-green-700 font-medium"
          >
            Scan Another Leaf
          </button>
        </div>
      )}

      {status === 'error' && (
        <div className="mt-10 text-center">
          <p className="text-red-600 text-sm mb-4">Connection issue — please try again.</p>
          <button
            onClick={reset}
            className="py-3 px-6 rounded-2xl bg-green-600 text-white font-medium"
          >
            Retry
          </button>
        </div>
      )}
    </div>
  )
}
